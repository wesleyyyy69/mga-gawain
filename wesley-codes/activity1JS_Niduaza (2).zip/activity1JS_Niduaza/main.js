const kelvin = 283;
const celsius = kelvin - 273;
const fahrenheit = (celsius * 9/5) + 32;

console.log(`The temperature is ${fahrenheit} degrees Fahrenheit.`);