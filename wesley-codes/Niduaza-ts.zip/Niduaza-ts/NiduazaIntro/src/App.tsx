import { useState } from 'react'
import profilePic from './assets/pfp.jpg'
import './App.css'

const INTRO_MSG: string = "Hello! I'm Wesley Bryant S. Niduaza "

function App() {
  const [showMore, setShowMore] = useState<boolean>(false)
  const toggleShow = () => setShowMore(!showMore)

  return (
    <div
      className="flex flex-col items-center justify-center text-center w-screen h-screen overflow-hidden"
      style={{
        background: `
          radial-gradient(circle at top left, rgba(59,130,246,0.9) 0%, rgba(37,99,235,0.85) 35%, transparent 70%),
          radial-gradient(circle at bottom right, rgba(239,68,68,0.5) 0%, transparent 60%),
          linear-gradient(135deg, #1e3a8a 0%, #1e40af 100%)
        `,
        backgroundBlendMode: "overlay",
        color: "white",
        transition: "background 0.5s ease-in-out",
        position: "relative",
        padding: "1rem",
      }}
    >
  
      <img
        src={profilePic}
        alt="Profile"
        style={{
          width: '200px',
          height: '200px',
          borderRadius: '50%',
          border: '4px solid #fff',
          marginBottom: '1.5rem',
          boxShadow: '0 0 30px rgba(239,68,68,0.4)',
          objectFit: 'cover',
          transition: 'transform 0.3s ease, box-shadow 0.3s ease',
        }}
        onMouseOver={e => {
          e.currentTarget.style.transform = 'scale(1.05)'
          e.currentTarget.style.boxShadow = '0 0 50px rgba(239,68,68,0.6)'
        }}
        onMouseOut={e => {
          e.currentTarget.style.transform = 'scale(1)'
          e.currentTarget.style.boxShadow = '0 0 30px rgba(239,68,68,0.4)'
        }}
      />

      <h1
        style={{
          fontSize: "3rem",
          fontWeight: "bold",
          textShadow: "2px 2px 10px rgba(0,0,0,0.3)",
          marginBottom: "0.5rem",
        }}
      >
        {INTRO_MSG}
      </h1>

      <p
        style={{
          fontSize: "1.2rem",
          opacity: 0.9,
          maxWidth: "700px",
          lineHeight: "1.7",
          textAlign: "center",
          margin: "0 auto",
        }}
      >
        18 years old, i live in 122f 2nd St. Agaptio Subdivision Rosario Pasig City. I am currently a student at MFI Polytechnic Institute, pursuing a course in Information Technology. I have a passion for coding and technology, and I am excited to learn and grow in this field.
      </p>

      <button
        onClick={toggleShow}
        style={{
          background: showMore
            ? "linear-gradient(90deg, #ef4444, #f87171)"
            : "linear-gradient(90deg, #3b82f6, #2563eb)",
          color: "#fff",
          border: "none",
          padding: "14px 36px",
          borderRadius: "10px",
          marginTop: "2rem",
          cursor: "pointer",
          fontWeight: "bold",
          fontSize: "1rem",
          boxShadow: "0 6px 25px rgba(0,0,0,0.3)",
          transition: "transform 0.3s ease, box-shadow 0.3s ease",
        }}
        onMouseOver={e => {
          e.currentTarget.style.transform = "scale(1.08)"
          e.currentTarget.style.boxShadow = "0 8px 35px rgba(0,0,0,0.4)"
        }}
        onMouseOut={e => {
          e.currentTarget.style.transform = "scale(1.0)"
          e.currentTarget.style.boxShadow = "0 6px 25px rgba(0,0,0,0.3)"
        }}
      >
        {showMore ? "Hide Details" : "About Me"}
      </button>

      {showMore && (
        <div
          style={{
            marginTop: "3rem",
            background: "rgba(255, 255, 255, 0.1)",
            padding: "3rem",
            borderRadius: "30px",
            maxWidth: "600px",
            width: "90%",
            textAlign: "center",
            boxShadow: "0 0 25px rgba(255,255,255,0.08)",
            backdropFilter: "blur(100px)",
            lineHeight: "2.0",
            position: "relative",
            left: "50%",
            transform: "translateX(-50%)",
            display: "flex",
            flexDirection: "column",
            alignItems: "center",
            justifyContent: "center"
          }}
        >
          <div style={{ width: "100%", maxWidth: "500px", margin: "0 auto" }}>
             <h3 style={{ fontWeight: "bold", fontSize: "1.5rem", marginBottom: "1rem" }}>Random information about me</h3>
             <p>I was born on December 6, 2006. I'm the eldest child in my family, and my favorite color is blue. I love playing basketball and online games with my friends during my free time. I also enjoy watching movies and listening to music, and my favorite dish is chicken curry and my most disliked food is ampalaya.</p>
            <h3 style={{ fontWeight: "bold", fontSize: "1.5rem", marginBottom: "1rem" }}>Education</h3>
            <p>Elementary: Maybunga Elementary School MAIN</p>
            <p>Junior High School: Rizal High School</p>
            <p>Senior High School: Senior High School</p>
            <p>Currently Studying at: MFI Polytechnic Institute</p>

            <h3 style={{ fontWeight: "bold", fontSize: "1.5rem", marginTop: "1.5rem" }}>Interests</h3>
            <p>Coding, Sports (especially basketball), watching movies, listening to music</p>

            <h3 style={{ fontWeight: "bold", fontSize: "1.5rem", marginTop: "1.5rem" }}>Goal</h3>
            <p>To become a skillful IT one day</p>

            <h3 style={{ fontWeight: "bold", fontSize: "1.5rem", marginTop: "1.5rem" }}>Motto</h3>
            <p>Onting bato, onting semento, monumento</p>
          </div>
        </div>
      )}
    </div>
  )
}

export default App
