const name = "Wesley Niduaza";
const my_age = 18;
const dog_age = (my_age - 2) * 4 + (10.5 * 2);
const scarlett = 7;
const scarlett_human = 21 + (scarlett - 2) * 4;
const ascii = `
           / \__
     (    @\___
      /         O
     /   (_____/
    /_____/   U

`;

console.log(`My name is ${name}. I am ${my_age} years old in human years which is ${dog_age} years old in dog years. \n`);
console.log(`This is Scarlett, my dog! She is ${scarlett} years old in dog years, which makes her ${scarlett_human} years old in human years.`);
console.log(ascii);