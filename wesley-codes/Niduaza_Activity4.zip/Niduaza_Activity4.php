<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, intial-scale=1.0">
    <link rel="stylesheet" href="main.css"/>
    <title>PHP Lesson 4</title>
    <!DOCTYPE html>
<html>
<body>

    <h1>
        <?php echo "My name is Wesley Bryant Niduaza 18 years old from Rosario Pasig City"; ?>
    </h1>

    <h2>
        <?php echo "My Hobbies"; ?>
    </h2>
        <ul>
            <il> <?php echo "Basketball" ?>
            <il> <?php echo "play online games" ?>
            <il> <?php echo "Listening music" ?>
        </ul>

    <h2>
        <?php echo "My Educational Attainment"; ?>
    </h2>
        <ul>
            <il> <?php echo "I went to Rizal High School from 2019-2025" ?>
            
            <il> <?php echo "And now I currently studying at MFI Polytechnic Institute" ?>
        </ul>

    <h2>
        <?php echo "My Likes and Dislikes"; ?>
    </h2>
        <ul>
            <il> <?php echo "MY LIKES IN FOODS" ?>
        <ul>
            <il> <?php echo "Sisig" ?>
            <il> <?php echo "Potato Corner" ?>
            <il> <?php echo "Coffee" ?>
            <il> <?php echo "Burger" ?>
        </ul>
        <il> <?php echo "MY FAVOURITE" ?>
        <ul>
            <il> <?php echo "Sleep" ?>
            <il> <?php echo "Eat" ?>
            <il> <?php echo "Basketball" ?>
            <il> <?php echo "Online games" ?>
        </ul>
            <il> <?php echo 
"MY DISLIKES" ?>
        <ul>
            <il> <?php echo "Too Many hehe" ?>
        </ul>


</body>
</html>
</head>
</html>